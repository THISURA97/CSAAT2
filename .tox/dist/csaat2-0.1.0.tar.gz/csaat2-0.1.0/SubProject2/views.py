from django.http import HttpResponse


# Create your views here.
def SubProject2(request):
    return HttpResponse("Sub Project 2")
