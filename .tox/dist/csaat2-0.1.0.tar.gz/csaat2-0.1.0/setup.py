# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['SubProject1',
 'SubProject1.migrations',
 'SubProject2',
 'SubProject2.migrations']

package_data = \
{'': ['*']}

install_requires = \
['Django>=3.1.5,<4.0.0',
 'black>=20.8b1,<21.0',
 'coverage>=5.3.1,<6.0.0',
 'flakehell>=0.7.1,<0.8.0',
 'gunicorn>=20.0.4,<21.0.0',
 'isort>=5.7.0,<6.0.0',
 'mypy>=0.790,<0.791',
 'pre-commit>=2.9.3,<3.0.0',
 'tox>=3.21.0,<4.0.0',
 'whitenoise>=5.2.0,<6.0.0']

setup_kwargs = {
    'name': 'csaat2',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'thisura97',
    'author_email': 'tdinith481@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
