from django.apps import AppConfig


class Subproject2Config(AppConfig):
    name = "SubProject2"
