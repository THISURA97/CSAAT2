from django.http import HttpResponse


# Create your views here.
def SubProject1(request):
    return HttpResponse("Sub Project 1")
