from django.apps import AppConfig


class Subproject1Config(AppConfig):
    name = "SubProject1"
